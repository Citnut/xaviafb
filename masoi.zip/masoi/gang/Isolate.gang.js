import Gang from './Gang.js';

export default class Isolate extends Gang {};
