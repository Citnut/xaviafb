export {default as Werewolf} from "./Werewolf.gang.js"
export {default as Isolate} from "./Isolate.gang.js"
