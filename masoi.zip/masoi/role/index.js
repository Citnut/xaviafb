import messageApprentice from "./Apprentice.js"
import messageBodyguard from "./Bodyguard.js"
import messageCupid from "./Cupid.js"
import messageEvilseer from "./Evilseer.js"
import messageFruitbrute from "./Fruitbrute.js"
import messageGoodseer from "./Goodseer.js"
import messageHunter from "./Hunter.js"
import messageInvestigator from "./Investigator.js"
import messageLycan from "./Lycan.js"
import messageOldman from "./Oldman.js"
import messageTanner from "./Tanner.js"
import messageVillager from "./Villager.js"
import messageWerewolf from "./Werewolf.js"
import messageWitch from "./Witch.js"
import messageMayor from "./Mayor.js"
import messageMinion from "./Minion.js"
import messageDiseased from "./Diseased.js"
import messagePacifist from "./Pacifist.js"


export default {
	messageApprentice,
	messageBodyguard,
	messageCupid,
	messageEvilseer,
	messageFruitbrute,
	messageGoodseer,
	messageHunter,
	messageInvestigator,
	messageLycan,
	messageOldman,
	messageTanner,
	messageVillager,
	messageWerewolf,
	messageWitch,
	messageMayor,
	messageMinion,
	messageDiseased,
	messagePacifist
}
