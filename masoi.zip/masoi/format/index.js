// import alive from "./alive.format.js"
// import diff from "./diff.format.js"
// import diff2 from "./diff2.format.js"
// import notSelf from "./notSelf.format.js"
// import validIndex from "./validIndex.format.js"

// export default {
// 	alive,//require('./alive.format')
// 	diff,//: require('./diff.format')
// 	diff2,//: require('./diff2.format'),
// 	notSelf,//: require('./notSelf.format'),
// 	validIndex,//: require('./validIndex.format')
// };
export { default as alive } from "./alive.format.js"
export { default as diff } from "./diff.format.js"
export { default as diff2 } from "./diff2.format.js"
export { default as notSelf } from "./notSelf.format.js"
export { default as validIndex } from "./validIndex.format.js"