import World from './World.js';

export default class Normal extends World {
	constructor(options) {
		super(options);
	}
};
