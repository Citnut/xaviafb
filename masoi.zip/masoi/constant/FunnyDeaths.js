export default [
	'ngủm',
	'chết',
	'tắt thở',
	'ra đi',
	'ngỏm củ tỏi',
	'bay màu'
];
