export {default as Data} from "./Data.js"
export {default as FunnyDeaths} from "./FunnyDeaths.js"
